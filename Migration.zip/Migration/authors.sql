-- Table: public.authors

-- DROP TABLE IF EXISTS public.authors;

CREATE TABLE IF NOT EXISTS public.authors
(
    au_id character varying(11) COLLATE pg_catalog."default" NOT NULL,
    au_lname character varying(40) COLLATE pg_catalog."default" NOT NULL,
    au_fname character varying(20) COLLATE pg_catalog."default" NOT NULL,
    phone character(12) COLLATE pg_catalog."default" NOT NULL DEFAULT 'UNKNOWN'::bpchar,
    trial_address_5 character varying(40) COLLATE pg_catalog."default",
    trial_city_6 character varying(20) COLLATE pg_catalog."default",
    state character(2) COLLATE pg_catalog."default",
    trial_zip_8 character(5) COLLATE pg_catalog."default",
    contract boolean NOT NULL,
    CONSTRAINT upkcl_auidind PRIMARY KEY (au_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.authors
    OWNER to postgres;
-- Index: aunmind

-- DROP INDEX IF EXISTS public.aunmind;

CREATE INDEX IF NOT EXISTS aunmind
    ON public.authors USING btree
    (au_lname COLLATE pg_catalog."default" ASC NULLS LAST, au_fname COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;