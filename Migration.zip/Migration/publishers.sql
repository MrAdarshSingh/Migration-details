-- Table: public.publishers

-- DROP TABLE IF EXISTS public.publishers;

CREATE TABLE IF NOT EXISTS public.publishers
(
    pub_id character(4) COLLATE pg_catalog."default" NOT NULL,
    pub_name character varying(40) COLLATE pg_catalog."default",
    city character varying(20) COLLATE pg_catalog."default",
    state character(2) COLLATE pg_catalog."default",
    country character varying(30) COLLATE pg_catalog."default" DEFAULT 'USA'::character varying,
    CONSTRAINT upkcl_pubind PRIMARY KEY (pub_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.publishers
    OWNER to postgres;