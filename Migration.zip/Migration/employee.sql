-- Table: public.employee

-- DROP TABLE IF EXISTS public.employee;

CREATE TABLE IF NOT EXISTS public.employee
(
    trial_emp_id_1 character(9) COLLATE pg_catalog."default" NOT NULL,
    trial_fname_2 character varying(20) COLLATE pg_catalog."default" NOT NULL,
    trial_minit_3 character(1) COLLATE pg_catalog."default",
    lname character varying(30) COLLATE pg_catalog."default" NOT NULL,
    trial_job_id_5 smallint NOT NULL DEFAULT 1,
    job_lvl smallint DEFAULT 10,
    pub_id character(4) COLLATE pg_catalog."default" NOT NULL DEFAULT '9952'::bpchar,
    hire_date timestamp(6) without time zone NOT NULL DEFAULT now(),
    CONSTRAINT pk_emp_id PRIMARY KEY (trial_emp_id_1),
    CONSTRAINT fk__employee__job_id__5be2a6f2 FOREIGN KEY (trial_job_id_5)
        REFERENCES public.jobs (trial_job_id_1) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk__employee__pub_id__5ebf139d FOREIGN KEY (pub_id)
        REFERENCES public.publishers (pub_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.employee
    OWNER to postgres;
-- Index: employee_ind

-- DROP INDEX IF EXISTS public.employee_ind;

CREATE INDEX IF NOT EXISTS employee_ind
    ON public.employee USING btree
    (lname COLLATE pg_catalog."default" ASC NULLS LAST, trial_fname_2 COLLATE pg_catalog."default" ASC NULLS LAST, trial_minit_3 COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;