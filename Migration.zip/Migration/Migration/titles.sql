-- Table: public.titles

-- DROP TABLE IF EXISTS public.titles;

CREATE TABLE IF NOT EXISTS public.titles
(
    trial_title_id_1 character varying(6) COLLATE pg_catalog."default" NOT NULL,
    trial_title_2 character varying(80) COLLATE pg_catalog."default" NOT NULL,
    type character(12) COLLATE pg_catalog."default" NOT NULL DEFAULT 'UNDECIDED'::bpchar,
    trial_pub_id_4 character(4) COLLATE pg_catalog."default",
    price numeric(19,4),
    trial_advance_6 numeric(19,4),
    royalty integer,
    ytd_sales integer,
    notes character varying(200) COLLATE pg_catalog."default",
    trial_pubdate_10 timestamp(6) without time zone NOT NULL DEFAULT now(),
    CONSTRAINT upkcl_titleidind PRIMARY KEY (trial_title_id_1),
    CONSTRAINT fk__titles__pub_id__412eb0b6 FOREIGN KEY (trial_pub_id_4)
        REFERENCES public.publishers (pub_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.titles
    OWNER to postgres;
-- Index: titleind

-- DROP INDEX IF EXISTS public.titleind;

CREATE INDEX IF NOT EXISTS titleind
    ON public.titles USING btree
    (trial_title_2 COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;