-- Table: public.stores

-- DROP TABLE IF EXISTS public.stores;

CREATE TABLE IF NOT EXISTS public.stores
(
    stor_id character(4) COLLATE pg_catalog."default" NOT NULL,
    stor_name character varying(40) COLLATE pg_catalog."default",
    stor_address character varying(40) COLLATE pg_catalog."default",
    city character varying(20) COLLATE pg_catalog."default",
    trial_state_5 character(2) COLLATE pg_catalog."default",
    zip character(5) COLLATE pg_catalog."default",
    CONSTRAINT upk_storeid PRIMARY KEY (stor_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.stores
    OWNER to postgres;