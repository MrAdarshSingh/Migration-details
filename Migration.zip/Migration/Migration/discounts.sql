-- Table: public.discounts

-- DROP TABLE IF EXISTS public.discounts;

CREATE TABLE IF NOT EXISTS public.discounts
(
    discounttype character varying(40) COLLATE pg_catalog."default" NOT NULL,
    stor_id character(4) COLLATE pg_catalog."default",
    trial_lowqty_3 smallint,
    highqty smallint,
    discount numeric(4,2) NOT NULL,
    CONSTRAINT fk__discounts__stor___4f7cd00d FOREIGN KEY (stor_id)
        REFERENCES public.stores (stor_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.discounts
    OWNER to postgres;