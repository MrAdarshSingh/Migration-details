-- Table: public.pub_info

-- DROP TABLE IF EXISTS public.pub_info;

CREATE TABLE IF NOT EXISTS public.pub_info
(
    trial_pub_id_1 character(4) COLLATE pg_catalog."default" NOT NULL,
    trial_logo_2 bytea,
    pr_info text COLLATE pg_catalog."default",
    CONSTRAINT upkcl_pubinfo PRIMARY KEY (trial_pub_id_1),
    CONSTRAINT fk__pub_info__pub_id__571df1d5 FOREIGN KEY (trial_pub_id_1)
        REFERENCES public.publishers (pub_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.pub_info
    OWNER to postgres;