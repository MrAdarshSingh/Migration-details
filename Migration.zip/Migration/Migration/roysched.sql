-- Table: public.roysched

-- DROP TABLE IF EXISTS public.roysched;

CREATE TABLE IF NOT EXISTS public.roysched
(
    title_id character varying(6) COLLATE pg_catalog."default" NOT NULL,
    lorange integer,
    hirange integer,
    trial_royalty_4 integer,
    CONSTRAINT fk__roysched__title___4d94879b FOREIGN KEY (title_id)
        REFERENCES public.titles (trial_title_id_1) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.roysched
    OWNER to postgres;
-- Index: titleidind

-- DROP INDEX IF EXISTS public.titleidind;

CREATE INDEX IF NOT EXISTS titleidind
    ON public.roysched USING btree
    (title_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;