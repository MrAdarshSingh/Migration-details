-- Table: public.sales

-- DROP TABLE IF EXISTS public.sales;

CREATE TABLE IF NOT EXISTS public.sales
(
    stor_id character(4) COLLATE pg_catalog."default" NOT NULL,
    trial_ord_num_2 character varying(20) COLLATE pg_catalog."default" NOT NULL,
    ord_date timestamp(6) without time zone NOT NULL,
    qty smallint NOT NULL,
    payterms character varying(12) COLLATE pg_catalog."default" NOT NULL,
    title_id character varying(6) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT upkcl_sales PRIMARY KEY (stor_id, trial_ord_num_2, title_id),
    CONSTRAINT fk__sales__stor_id__4ab81af0 FOREIGN KEY (stor_id)
        REFERENCES public.stores (stor_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk__sales__title_id__4bac3f29 FOREIGN KEY (title_id)
        REFERENCES public.titles (trial_title_id_1) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.sales
    OWNER to postgres;
-- Index: titleidind2

-- DROP INDEX IF EXISTS public.titleidind2;

CREATE INDEX IF NOT EXISTS titleidind2
    ON public.sales USING btree
    (title_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;