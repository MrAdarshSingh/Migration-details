-- Table: public.titleauthor

-- DROP TABLE IF EXISTS public.titleauthor;

CREATE TABLE IF NOT EXISTS public.titleauthor
(
    au_id character varying(11) COLLATE pg_catalog."default" NOT NULL,
    title_id character varying(6) COLLATE pg_catalog."default" NOT NULL,
    au_ord smallint,
    royaltyper integer,
    CONSTRAINT upkcl_taind PRIMARY KEY (au_id, title_id),
    CONSTRAINT fk__titleauth__au_id__44ff419a FOREIGN KEY (au_id)
        REFERENCES public.authors (au_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk__titleauth__title__45f365d3 FOREIGN KEY (title_id)
        REFERENCES public.titles (trial_title_id_1) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.titleauthor
    OWNER to postgres;
-- Index: auidind

-- DROP INDEX IF EXISTS public.auidind;

CREATE INDEX IF NOT EXISTS auidind
    ON public.titleauthor USING btree
    (au_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: titleidind1

-- DROP INDEX IF EXISTS public.titleidind1;

CREATE INDEX IF NOT EXISTS titleidind1
    ON public.titleauthor USING btree
    (title_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;